import { AppHome } from './app-home';

describe('app', () => {
  it('builds', () => {
    expect(new AppHome()).toBeTruthy();
  });
});
