import '@ionic/core';

// import { setupConfig } from '@ionic/core';

// setupConfig({
//   mode: 'ios'
// });
